/* Generated cache identity and immutable asset list are inserted during build. */
const CACHE = "mazen-workers-seo-v3-1792714421314";
const FILES = ["/404.html","/ar/about/index.html","/ar/compress-image/index.html","/ar/contact/index.html","/ar/convert-image/index.html","/ar/guide/index.html","/ar/image-guide/index.html","/ar/images-pdf/index.html","/ar/index.html","/ar/merge-pdf/index.html","/ar/password/index.html","/ar/pdf-guide/index.html","/ar/pdf-images/index.html","/ar/privacy/index.html","/ar/qr-code/index.html","/ar/resize-image/index.html","/ar/split-pdf/index.html","/ar/terms/index.html","/ar/text-tools/index.html","/ar/word-counter/index.html","/assets/_commonjsHelpers-CqkleIqs.js","/assets/browser-CujOq0-h.js","/assets/index-0eptdu7X.css","/assets/index-CYvYKO4Y.js","/assets/index-Cy3vbBxk.js","/assets/pdf-CcZYcL52.js","/assets/pdf.worker.min-yatZIOMy.mjs","/boot-health.js","/en/about/index.html","/en/compress-image/index.html","/en/contact/index.html","/en/convert-image/index.html","/en/guide/index.html","/en/image-guide/index.html","/en/images-pdf/index.html","/en/index.html","/en/merge-pdf/index.html","/en/password/index.html","/en/pdf-guide/index.html","/en/pdf-images/index.html","/en/privacy/index.html","/en/qr-code/index.html","/en/resize-image/index.html","/en/split-pdf/index.html","/en/terms/index.html","/en/text-tools/index.html","/en/word-counter/index.html","/icon-192.png","/icon-512.png","/icon.svg","/index.html","/manifest.webmanifest","/robots.txt","/sitemap.xml"];
const ASSETS = new Set(FILES);
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const versions = (await caches.keys()).filter(key => key.startsWith('mazen-'));
    // Keep one previous asset generation for documents still open in other tabs.
    const previous = versions.filter(key => key !== CACHE).slice(-1);
    await Promise.all(versions.filter(key => key !== CACHE && !previous.includes(key)).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      // Prefer deployed HTML; never trap a returning user on an obsolete app shell.
      try { const response = await fetch(request); if (response.ok) return response; } catch {}
      const cache = await caches.open(CACHE);
      const pathname = url.pathname.endsWith('/') ? url.pathname + 'index.html' : url.pathname;
      return await cache.match(pathname, {ignoreVary:true}) || new Response('Page unavailable offline', {status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});
    })());
    return;
  }
  if (!ASSETS.has(url.pathname) && !url.pathname.startsWith('/assets/')) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(request, {ignoreVary:true});
    if (cached) return cached;
    // Hash-named files are safe to reuse across releases; HTML is not.
    if (url.pathname.startsWith('/assets/')) {
      const retained = await caches.match(request, {ignoreVary:true});
      if (retained) return retained;
    }
    return fetch(request);
  })());
});
