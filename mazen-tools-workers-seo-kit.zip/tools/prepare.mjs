import {readFile,writeFile,readdir,access} from 'node:fs/promises';
import path from 'node:path';import {fileURLToPath} from 'node:url';
const kit=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const args=process.argv.slice(2),value=k=>args.includes(k)?args[args.indexOf(k)+1]:null;
const site=path.resolve(value('--site')||path.join(kit,'site'));const mode=value('--mode')||'staging';
if(!['staging','review'].includes(mode))throw Error('Mode must be staging or review');
const raw=value('--origin');let origin=null;
if(raw){const u=new URL(raw);if(u.protocol!=='https:'||u.port||u.username||u.password||u.search||u.hash||!['','/'].includes(u.pathname)||u.hostname!=='mazentoolsfree.mazooniosman299.workers.dev')throw Error('Use the exact production origin returned by Cloudflare: mazentoolsfree.mazooniosman299.workers.dev only; no preview aliases');origin=u.origin;}
if(mode==='review'&&(!origin||!args.includes('--confirm-assigned-origin')))throw Error('Review mode requires the actual assigned origin and --confirm-assigned-origin. This does not verify AdSense acceptance.');
const publisher=process.env.ADSENSE_PUBLISHER_ID||'',gsc=process.env.GSC_VERIFICATION_TOKEN||'',seller=process.env.ADSENSE_ADS_TXT||'';
if(publisher&&(!/^ca-pub-\d{16}$/.test(publisher)||/^ca-pub-(0{16}|1234567890123456)$/.test(publisher)))throw Error('Invalid real publisher ID');
if(gsc&&!/^[A-Za-z0-9_-]{10,200}$/.test(gsc))throw Error('Invalid Google verification token');
if(seller&&(!publisher||seller.trim()!==`google.com, ${publisher.slice(3)}, DIRECT, f08c47fec0942fa0`))throw Error('The provided ads.txt line must match the real publisher ID');
async function walk(dir){let files=[];for(const e of await readdir(dir,{withFileTypes:true})){const p=path.join(dir,e.name);if(e.isDirectory())files.push(...await walk(p));else files.push(p)}return files}
const report=JSON.parse(await readFile(path.join(site,'build-report.json'),'utf8'));const oldOrigin=report.origin;
const metas=(gsc?`<meta name="google-site-verification" content="${gsc}">`:'')+(publisher?`<meta name="google-adsense-account" content="${publisher}">`:'');
for(const file of await walk(site)){if(file.endsWith('.html')){let html=await readFile(file,'utf8');if(origin)html=html.replaceAll(oldOrigin,origin);if(gsc)html=html.replace(/<meta name="google-site-verification" content="[^"]*">/g,'');if(publisher)html=html.replace(/<meta name="google-adsense-account" content="[^"]*">/g,'');html=html.replace('</head>',metas+'</head>');await writeFile(file,html)}}
if(origin){for(const name of ['robots.txt','sitemap.xml','readiness-report.json']){const file=path.join(site,name);try{await writeFile(file,(await readFile(file,'utf8')).replaceAll(oldOrigin,origin))}catch(error){if(error.code!=='ENOENT')throw error}}report.origin=origin;}
if(origin){try{const p=path.join(site,'readiness-report.json');const readiness=JSON.parse(await readFile(p,'utf8'));readiness.site=origin;readiness.domainAssessment={hostname:new URL(origin).hostname,publicSuffix:'workers.dev',registrableDomain:'mazooniosman299.workers.dev',isSubdomain:true,status:'requires-real-AdSense-account-domain-and-ownership-confirmation',note:'Assigned production host only. Actual eligibility, ownership and review must be verified in the real AdSense account.'};await writeFile(p,JSON.stringify(readiness,null,2)+'\n')}catch(e){if(e.code!=='ENOENT')throw e}}
report.adsEnabled=false;report.analyticsEnabled=false;report.searchConsoleVerificationConfigured=!!gsc||report.searchConsoleVerificationConfigured;report.adSenseVerificationConfigured=!!publisher||report.adSenseVerificationConfigured;report.cloudflarePackageMode=mode;report.assignedOriginConfirmed=!!origin&&args.includes('--confirm-assigned-origin');
await writeFile(path.join(site,'build-report.json'),JSON.stringify(report,null,2)+'\n');
let headers=(await readFile(path.join(site,'_headers'),'utf8')).replace(/^\s*X-Robots-Tag: noindex, nofollow\s*$/mg,'');
if(mode==='staging')headers=headers.replace('/*','/*\n  X-Robots-Tag: noindex, nofollow');
headers=headers.replace(/\n\/sw\.js\n  Cache-Control: no-cache\n?/g,'\n');
headers+='\n/sw.js\n  Cache-Control: no-cache\n';await writeFile(path.join(site,'_headers'),headers);
await writeFile(path.join(site,'_redirects'),'/ar /ar/ 301\n/en /en/ 301\n');
if(seller)await writeFile(path.join(site,'ads.txt'),seller.trim()+'\n');
// Only public app assets are cached. Never cache publisher declarations or ownership files.
const files=(await walk(site)).map(p=>'/'+path.relative(site,p).split(path.sep).join('/')).filter(p=>!['/_headers','/_redirects','/sw.js','/build-report.json','/readiness-report.json','/ads.txt'].includes(p)&&!/^\/google[^/]*\.html$/.test(p));
const sw=await readFile(path.join(kit,'tools/service-worker.template.js'),'utf8');await writeFile(path.join(site,'sw.js'),sw.replace("'__CACHE__'",JSON.stringify('mazen-workers-seo-v3-'+Date.now())).replace('__FILES__',JSON.stringify(files)));
console.log(JSON.stringify({mode,canonicalOrigin:report.origin,actualCloudflareOriginConfirmed:report.assignedOriginConfirmed,adsEnabled:false,verificationTagsAdded:{searchConsole:!!gsc,adSense:!!publisher},note:mode==='staging'?'Upload-ready staging: noindex; existing canonical preserved unless an assigned origin is supplied.':'Crawlable review candidate; neither Google ownership nor AdSense acceptance is implied.'},null,2));
