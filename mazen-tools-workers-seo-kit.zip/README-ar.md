# تحديث SEO لموقع Mazen Tools الحالي

العنوان الوحيد المستهدف: https://mazentoolsfree.mazooniosman299.workers.dev/

حزمة الموقع ZIP تحتوي ملفات الإنتاج مباشرة. ارفعها كتحديث للأصول في Worker الحالي mazentoolsfree من لوحة Cloudflare، بنفس طريقة رفع النسخة العاملة. لا تنشئ Worker جديداً ولا تحذف الحالي. إعداد wrangler.jsonc المرفق خارج ZIP نموذج للموقع الثابت فقط؛ لم يمكن قراءة إعدادات الحساب الحالية ولا استبدالها. يلزم مطابقة إعدادات Worker الحالي قبل استخدام CLI، خصوصاً إن كانت له شيفرة خادم أو bindings.

لم يُعد بناء التطبيق؛ ملفات JavaScript وCSS والمكتبات والصور كما هي بالبايت. تغيّرت بيانات HTML الخاصة بالأصل وروابط اللغات والخريطة وrobots وتقارير النطاق وترويسات الفهرسة وإصدار كاش Service Worker. صفحات الخطأ تبقى noindex. الصفحات العربية والإنجليزية تشمل أمثلة وحدود الأدوات والأسئلة الشائعة والمحتوى الأصلي والخصوصية والشروط والتواصل الحقيقي المصرح به mazenosman968@gmail.com. تسليم البريد لم يُختبر.

## Google Search Console
أضف خاصية URL-prefix للرابط الكامل أعلاه في حساب Google الخاص بك. انسخ رمز تحقق HTML الحقيقي فقط؛ لا ترسل كلمة مرور أو رموز تسجيل دخول. يمكن إدراج رمز الملكية العام في جميع الصفحات باستخدام أدوات الحزمة دون إعادة بناء:

GSC_VERIFICATION_TOKEN='ACTUAL_PUBLIC_TOKEN' node tools/prepare.mjs --mode review --origin https://mazentoolsfree.mazooniosman299.workers.dev --confirm-assigned-origin

بعد نشر الرمز والتحقق في Google، قدم https://mazentoolsfree.mazooniosman299.workers.dev/sitemap.xml وافحص صفحة عربية وإنجليزية. لم يتم تنفيذ التحقق أو تقديم الخريطة نيابة عن الحساب. robots يسمح بالزحف؛ لا يضمن الفهرسة. إذا أبقيت النسخة القديمة عامة، روابط canonical تشير هنا في هذه النسخة فقط؛ إعدادات النسخة القديمة لم تتغير.

## AdSense
لا توجد إعلانات مفعلة أو بيانات ناشر مصطنعة أو ملف ads.txt وهمي. بيانات ناشر AdSense الحقيقية تسمح بإضافة وسم إثبات الملكية فقط عبر ADSENSE_PUBLISHER_ID؛ لا تفعل الإعلانات. يمكن إضافة سطر Google الحقيقي المطابق عبر ADSENSE_ADS_TXT بعد أن ينطبق على الموقع. قبل الإعلانات يجب تأكيد أهلية الموقع وملكيته ومراجعته، وتكامل منصة موافقات معتمدة من Google حيث يلزم، وتحديث سياسة الخصوصية وCSP. هذه المتطلبات لم تُستكمل ولا يجوز تفسير الحزمة بأنها موافقة.

Google يتيح النطاقات وأنواعاً من نطاقات منصات PSL. PSL الحالي يضم workers.dev؛ النطاق القابل للتسجيل لهذا الرابط هو mazooniosman299.workers.dev والرابط الفعلي تحته. لذلك لا يوجد أساس للجزم بقبول المضيف الكامل كموقع مستقل. يلزم اختبار الإضافة والتحقق الحقيقي داخل AdSense، وقد تتطلب إدارة الملكية وads.txt على نطاق الحساب الأب؛ استضافة Worker الحالي لا تثبت هذه السيطرة. لا ننقل الموقع ولا نشتري نطاقاً. قابلية فهرسة الصفحات منفصلة عن قبول AdSense.

المصادر:
https://support.google.com/adsense/answer/12170421
https://support.google.com/adsense/answer/7584263
https://support.google.com/webmasters/answer/9008080
https://developers.cloudflare.com/workers/configuration/routing/workers-dev/
https://raw.githubusercontent.com/publicsuffix/list/master/public_suffix_list.dat

## الحالة الفعلية
حساب Cloudflare غير مصادق داخل بيئة العمل. محاولة الوصول العام تعيد CONNECT 403 من وكيل شبكة البيئة؛ لم تصل إلى الموقع ولم نحكم منها على استجابته. لم يتم نشر هذا التحديث. الموقع الحالي لم يتغير. نتائج الاختبارات المرفقة تخص نسخة الحزمة محلياً على Chromium بحجمي الكمبيوتر والهاتف، وليست دليلاً على اختبارات عنوان Cloudflare العام.
