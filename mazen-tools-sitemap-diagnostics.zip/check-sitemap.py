import argparse,json,urllib.request,urllib.parse,urllib.robotparser,xml.etree.ElementTree as ET
from pathlib import Path
from html.parser import HTMLParser
p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--require-self',action='store_true');a=p.parse_args();base=a.base.rstrip('/');origin='https://mazentoolsfree.mazooniosman299.workers.dev'
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):return None
opener=urllib.request.build_opener(NoRedirect)
def fetch(path):
 with opener.open(urllib.request.Request(base+path,headers={'User-Agent':'MazenTools-Sitemap-Check/1.0'}),timeout=15) as r:
  assert r.status==200,(path,r.status)
  assert 'noindex' not in r.headers.get('X-Robots-Tag','').lower(),path
  return r.headers,r.read()
h,body=fetch('/sitemap.xml');assert h.get_content_type() in ['application/xml','text/xml'];root=ET.fromstring(body);ns={'s':'http://www.sitemaps.org/schemas/sitemap/0.9','x':'http://www.w3.org/1999/xhtml'}
if a.require_self:
 assert h.get_content_charset()=='utf-8' and 'must-revalidate' in h.get('Cache-Control','')
assert root.tag=='{'+ns['s']+'}urlset';urls=root.findall('s:url',ns);assert len(urls)==38
rh,rb=fetch('/robots.txt');assert rh.get_content_type()=='text/plain';robots=urllib.robotparser.RobotFileParser();robots.parse(rb.decode().splitlines());assert origin+'/sitemap.xml' in robots.site_maps()
seen=set()
for item in urls:
 loc=item.find('s:loc',ns).text;assert loc.startswith(origin+'/') and loc not in seen;seen.add(loc);path=loc[len(origin):];assert robots.can_fetch('Googlebot',loc)
 ph,pb=fetch(path);assert ph.get_content_type()=='text/html';text=pb.decode();assert 'content="noindex' not in text;assert f'rel="canonical" href="{loc}"' in text or f'href="{loc}" rel="canonical"' in text
 links=item.findall('x:link',ns)
 for link in links:assert link.get('href').startswith(origin+'/')
 if a.require_self:
  assert {x.get('hreflang') for x in links}>={'ar','en'}
  assert any(x.get('href')==loc for x in links)
assert all(link.get('href') in seen for item in urls for link in item.findall('x:link',ns))
try:opener.open(base+'/nonexistent-sitemap-check-404',timeout=10);raise AssertionError('Missing URL returned success')
except urllib.error.HTTPError as e:assert e.code==404
with urllib.request.urlopen(base+'/google611146e9ceec162a.html',timeout=15) as verification:
 assert verification.status==200 and verification.read()==b'google-site-verification: google611146e9ceec162a.html'
print(json.dumps({'scope':'HTTP checks against supplied base, not Google indexing confirmation','base':base,'sitemapStatus':200,'contentType':h.get_content_type(),'xmlValid':True,'urlsChecked':len(seen),'robotsAllowsGooglebot':True,'canonicalMatches':True,'redirectsRejected':True,'verificationFilePreserved':True,'real404':True},indent=2))
